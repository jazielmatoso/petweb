--- README 

Pacote ClassLibrary2 é o Backend do projeto